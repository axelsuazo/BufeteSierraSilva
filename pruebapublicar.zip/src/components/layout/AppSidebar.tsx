// Este archivo será eliminado y reemplazado por AppNavbar.tsx
// Puedes borrar el contenido de este archivo o el archivo mismo.
// Dejaré un comentario para indicar que se ha movido.
// La funcionalidad se ha migrado a AppNavbar.tsx
